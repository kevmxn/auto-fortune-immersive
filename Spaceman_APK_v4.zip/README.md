# Spaceman APK
App Android (nueva, id `com.spaceman.apk`) que se conecta al websocket de Spaceman y emite señales
en una alerta flotante. En la pantalla de Configuración se elige el tipo de señales (Tiempo, 4x4 o Ambas):

1) **Tiempo** – registra sola cada ronda por categoría (5-6.99x, 7-8.99x, 9-9.99x, 10-29.99x, 30-49.99x, 50x+),
   estima el próximo pico (promedio de intervalos, mínimo 4 registros) y avisa 60 s antes.

2) **4x4** – matriz 5x5 (últimas 25 rondas). Entrada cuando la última ronda es >= 2.00x, F1 tiene 4-5 rondas >= 2.00x
   y C5 tiene 4-5 rondas >= 2.00x. Cada entrada tiene 3 intentos (3 rondas) para llegar al retiro (2x o 10x).
   La alerta muestra lo que evalúa el modelo (Últ / F1 / C5) mientras espera la entrada.

3) **Ambas** – corre Tiempo y 4x4 a la vez con los mismos datos del websocket: dos alertas flotantes
   independientes (Tiempo arriba, 4x4 debajo; se arrastran por separado) y los avisos de las dos.

**Historial guardado en el teléfono (las dos estrategias):** cada vez que el bot se conecta al websocket se abre una
conexión (C-01, C-02...) y todas las rondas se guardan con conexión y hora en
`Android/data/com.spaceman.apk/files/historial_rondas.csv`. Tiempo reconstruye sus registros con ese historial (últimas 3 h)
y 4x4 restaura su matriz con las rondas consecutivas (hueco máximo 2 min entre rondas guardadas).
Las señales 4x4 también se guardan en senales.csv.

Para cambiar de tipo de señales: detener e iniciar de nuevo.
Compilar: subir Spaceman_APK.zip al repositorio y ejecutar el workflow "Build Spaceman APK".
Ajustes de Tiempo (aviso, rondas, categorías): app/src/main/java/com/spaceman/apk/Config.kt
