package com.spaceman.apk

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Alerta flotante arrastrable: título en color + detalle (varias líneas). */
class FloatingAlert(private val ctx: Context, private val yDp: Int, private val onClose: () -> Unit) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private val root = LinearLayout(ctx)
    private val tTitle = TextView(ctx)
    private val tBody = TextView(ctx)
    private val bg = GradientDrawable()
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    )
    private var shown = false

    private fun dp(v: Int) = (v * d).toInt()

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(8), dp(10), dp(10))
        root.minimumWidth = dp(210)
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(Color.parseColor("#E6101420"))
        bg.setStroke(dp(2), Config.AMBAR)
        root.background = bg

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        tTitle.textSize = 17f
        tTitle.typeface = Typeface.DEFAULT_BOLD
        tTitle.setTextColor(Config.AMBAR)
        val close = TextView(ctx)
        close.text = "✕"
        close.setTextColor(Color.parseColor("#AAAAAA"))
        close.textSize = 16f
        close.setPadding(dp(14), 0, dp(4), dp(4))
        close.setOnClickListener { onClose() }
        top.addView(tTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(close)

        tBody.textSize = 15f
        tBody.setTextColor(Color.WHITE)

        root.addView(top)
        root.addView(tBody)

        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(10)
        lp.y = dp(yDp)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        root.setOnTouchListener { _: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(root, lp) } catch (_: Exception) { }
                }
            }
            true
        }
    }

    fun show() {
        if (!shown) { wm.addView(root, lp); shown = true }
    }

    fun hide() {
        if (shown) { try { wm.removeView(root) } catch (_: Exception) { }; shown = false }
    }

    fun update(titulo: String, detalle: CharSequence, accent: Int, mono: Boolean) {
        if (tTitle.text.toString() != titulo) tTitle.text = titulo
        tBody.typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
        tBody.textSize = if (mono) 11f else 15f
        if (tBody.text.toString() != detalle.toString()) tBody.text = detalle
        tBody.visibility = if (detalle.isEmpty()) View.GONE else View.VISIBLE
        tTitle.setTextColor(accent)
        bg.setStroke(dp(2), accent)
    }
}
