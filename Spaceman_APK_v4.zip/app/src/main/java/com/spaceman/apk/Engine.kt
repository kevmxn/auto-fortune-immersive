package com.spaceman.apk

/** Señal activa: ventana de rondas para conseguir el 2x. */
class Aviso(val cat: Categoria) {
    var saltar = Config.RONDAS_ENTRADA
    var intento = 1
    val resultados = ArrayList<Double>()
    val creadoMs = System.currentTimeMillis()
}

class Cierre(val ganada: Boolean, val titulo: String, val detalle: String, val hastaMs: Long)

class Estimado(
    val n: Int,
    val prom: Double,       // segundos entre picos
    val ultimo: Long,       // último registro (epoch s)
    val proximo: Double,    // próximo pico estimado (epoch s)
    val falta: Double,      // segundos hasta el próximo pico
    val activo: Boolean     // n >= MIN_REGISTROS
)

class Vista(val titulo: String, val detalle: CharSequence, val color: Int, val mono: Boolean = false)

/**
 * Estrategia del HTML + rondas del websocket.
 * 1) Cada ronda que cae dentro de una categoría se REGISTRA sola (como pulsar el botón).
 * 2) Con 4+ registros se estima el próximo pico: último + promedio de intervalos.
 * 3) A 60 s del pico estimado se emite la señal (una vez por ciclo).
 * 4) Tras el aviso, las siguientes rondas son los intentos para conseguir 2.00x.
 * Solo se usa desde el hilo principal.
 */
class Engine(previas: List<Pair<Long, Double>>, private val cb: Callbacks) {   // previas: (hora ms, multiplicador), más antigua primero

    interface Callbacks {
        fun alSenal(cat: Categoria)
        fun alFinal(ganada: Boolean)
    }

    private val registros = HashMap<String, ArrayList<Long>>()
    private val avisado = HashMap<String, Long>()   // categoría -> último registro por el que ya se avisó
    private val ultimas = ArrayList<Double>()
    private var aviso: Aviso? = null
    private var cierre: Cierre? = null

    init {
        // Los registros de cada categoría se reconstruyen con el historial guardado (incluye otras conexiones
        // y rondas vistas con la estrategia 4x4).
        for (c in Config.CATEGORIAS) registros[c.id] = ArrayList()
        for ((ms, v) in previas) {
            val cat = categoriaDe(v) ?: continue
            val l = registros.getOrPut(cat.id) { ArrayList() }
            l.add(ms / 1000)
            while (l.size > Config.MAX_REGISTROS_CAT) l.removeAt(0)
        }
    }

    fun categoriaDe(v: Double): Categoria? =
        Config.CATEGORIAS.firstOrNull { v >= it.min && v < it.max }

    fun reset() {
        for (c in Config.CATEGORIAS) registros[c.id] = ArrayList()
        avisado.clear()
        ultimas.clear()
        aviso = null
        cierre = null
    }

    fun estimado(c: Categoria, ahoraS: Double): Estimado? {
        val r = registros[c.id] ?: return null
        if (r.size < 2) return null
        var suma = 0.0
        for (i in 1 until r.size) suma += (r[i] - r[i - 1]).toDouble()
        val prom = suma / (r.size - 1)
        val ultimo = r[r.size - 1]
        val proximo = ultimo + prom
        return Estimado(r.size, prom, ultimo, proximo, proximo - ahoraS, r.size >= Config.MIN_REGISTROS)
    }

    /** Llega una ronda nueva del websocket. */
    fun onRound(valor: Double, ahoraMs: Long) {
        ultimas.add(0, valor)
        while (ultimas.size > 30) ultimas.removeAt(ultimas.size - 1)

        // 1) Resolver la señal activa con esta ronda
        val a = aviso
        if (a != null) {
            if (a.saltar > 0) {
                a.saltar--
            } else {
                a.resultados.add(valor)
                if (valor >= Config.TARGET) terminar(a, true, ahoraMs)
                else if (a.resultados.size >= a.cat.intentos) terminar(a, false, ahoraMs)
                else a.intento = a.resultados.size + 1
            }
        }

        // 2) Registrar automáticamente en su categoría (nuevo ciclo para esa categoría)
        val cat = categoriaDe(valor)
        if (cat != null) {
            val lista = registros.getOrPut(cat.id) { ArrayList() }
            lista.add(ahoraMs / 1000)
            while (lista.size > Config.MAX_REGISTROS_CAT) lista.removeAt(0)
        }
    }

    private fun terminar(a: Aviso, ganada: Boolean, ahoraMs: Long) {
        val t = fmt(Config.TARGET)
        cierre = if (ganada) {
            Cierre(true, "¡GANAMOS ${t}x!",
                "Resultado: ${fmt(a.resultados.last())}x - Intento ${a.resultados.size}",
                ahoraMs + Config.CIERRE_MS)
        } else {
            Cierre(false, "¡PERDIMOS ${t}x!",
                "Resultados: " + a.resultados.joinToString(">") { fmt(it) + "x" },
                ahoraMs + Config.CIERRE_MS)
        }
        aviso = null
        cb.alFinal(ganada)
    }

    /** Se llama cada segundo: decide si toca emitir una señal. */
    fun tick(ahoraMs: Long) {
        val ahoraS = ahoraMs / 1000.0
        val a = aviso
        if (a != null && ahoraMs - a.creadoMs > Config.AVISO_MAX_SEG * 1000L) aviso = null
        if (aviso != null) return

        var mejor: Categoria? = null
        var mejorFalta = Double.MAX_VALUE
        var mejorUltimo = 0L
        for (c in Config.CATEGORIAS) {
            val e = estimado(c, ahoraS) ?: continue
            if (!e.activo) continue
            if (e.falta > 0 && e.falta <= Config.AVISO_ANTES &&
                avisado[c.id] != e.ultimo && e.falta < mejorFalta
            ) {
                mejor = c; mejorFalta = e.falta; mejorUltimo = e.ultimo
            }
        }
        if (mejor != null) {
            avisado[mejor.id] = mejorUltimo
            aviso = Aviso(mejor)
            cierre = null
            cb.alSenal(mejor)
        }
    }

    /** Texto de la alerta flotante. */
    fun vista(ahoraMs: Long): Vista {
        val ahoraS = ahoraMs / 1000.0
        val f = cierre
        if (f != null) {
            if (ahoraMs < f.hastaMs) return Vista(f.titulo, f.detalle, if (f.ganada) Config.VERDE else Config.ROJO)
            cierre = null
        }
        val a = aviso
        if (a != null) {
            val e = estimado(a.cat, ahoraS)
            val t = if (e != null && e.falta > 0) mmss(e.falta) else "ahora"
            // Línea extra: en qué ronda empieza el intento
            val desde = if (a.saltar > 0) {
                if (a.saltar == 1) "Esperando a la siguiente..." else "Esperando ${a.saltar} rondas..."
            } else {
                "¡Ahora! Esta ronda es Intento ${a.intento} de ${a.cat.intentos}"
            }
            return Vista(
                "Señal ${a.cat.rango} - $t",
                "Retirar en ${fmt(Config.TARGET)}x - Intento ${a.intento}\n$desde",
                a.cat.color
            )
        }
        // Esperando: tiempo estimado de cada categoría lista
        val listas = ArrayList<Pair<Categoria, Double>>()
        for (c in Config.CATEGORIAS) {
            val e = estimado(c, ahoraS) ?: continue
            if (e.activo && e.falta > 0) listas.add(Pair(c, e.falta))
        }
        listas.sortBy { it.second }
        if (listas.isNotEmpty()) {
            return Vista("Tiempo Estimado...",
                listas.joinToString("\n") { "${it.first.rango} = ${mmss(it.second)}" }, Config.AMBAR)
        }
        val cal = Config.CATEGORIAS.filter { (registros[it.id]?.size ?: 0) > 0 }
        return if (cal.isEmpty()) {
            Vista("Tiempo Estimado...", "Esperando rondas...", Config.AMBAR)
        } else {
            Vista("Tiempo Estimado...",
                "Calentando\n" + cal.joinToString("\n") { "${it.rango} = ${registros[it.id]?.size ?: 0}/${Config.MIN_REGISTROS}" },
                Config.AMBAR)
        }
    }

    /** Resumen para la pantalla principal. */
    fun resumen(ahoraMs: Long): String {
        val ahoraS = ahoraMs / 1000.0
        val sb = StringBuilder()
        for (c in Config.CATEGORIAS) {
            val n = registros[c.id]?.size ?: 0
            sb.append(c.rango.padEnd(13)).append("  ").append(n).append('/').append(Config.MIN_REGISTROS)
            val e = estimado(c, ahoraS)
            if (e != null) {
                sb.append("  cada ").append(mmss(e.prom))
                if (e.activo) sb.append("  falta ").append(if (e.falta > 0) mmss(e.falta) else "pasó")
            }
            sb.append('\n')
        }
        sb.append("\nÚltimas rondas:\n")
        sb.append(if (ultimas.isEmpty()) "—" else ultimas.take(12).joinToString("  ") { fmt(it) })
        return sb.toString()
    }
}
