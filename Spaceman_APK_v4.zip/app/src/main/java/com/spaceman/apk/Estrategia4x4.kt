package com.spaceman.apk

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Estrategia 4x4 (portada de Aviator Pengüi 22) alimentada por el websocket.
 *
 * Matriz 5x5 = últimas 25 rondas (posición 1 = la más reciente). F1 = posiciones 1-5, C5 = 5,10,15,20,25.
 * Entrada: última ronda >= 2.00x, F1 con 4 o 5 rondas >= 2.00x y C5 con 4 o 5 rondas >= 2.00x.
 * Cada entrada tiene 3 intentos (3 rondas) para llegar al retiro (2x o 10x): gana en la primera ronda
 * que lo alcance; si las 3 rondas no lo alcanzan, pierde. Una ronda que resuelve una entrada nunca
 * genera otra entrada en esa misma ronda. Solo se usa desde el hilo principal.
 */
class Estrategia4x4(
    ctx: Context,
    val modo10x: Boolean,
    previas: List<Double>,                  // matriz restaurada del historial guardado (más reciente primero)
    private val conexionId: () -> Int,
    private val cb: Callbacks
) {

    interface Callbacks {
        fun alEntrada()
        fun alFinal(ganada: Boolean)
    }

    companion object {
        const val TRIGGER = 2.00
        const val MATRIX = 25
        const val MIN_FILA1 = 4
        const val MIN_COL5 = 4
        const val CASHOUT_2X = 2.00
        const val CASHOUT_10X = 10.00
        const val ENTRADA_INTENTOS = 3      // rondas disponibles por entrada
        const val MAX_HIST = 1000
        private const val PREFS = "spaceman_apk_4x4_v2"
        private const val CSV_SENALES = "N° Señal,Cuota,Resultado,Intento,Conexión,Hora\n"

        fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        fun clave(modo10x: Boolean) = if (modo10x) "10x" else "2x"

        /** Borra la tabla de señales (las estadísticas se conservan). */
        fun borrarHistorialPrefs(ctx: Context) {
            prefs(ctx).edit()
                .remove("senales_2x").remove("senales_10x")
                .putInt("proximoNumeroSenal_2x", 1).putInt("proximoNumeroSenal_10x", 1)
                .apply()
            try { File(ctx.getExternalFilesDir(null), "senales.csv").writeText(CSV_SENALES) } catch (_: Exception) { }
        }

        fun estadisticasTexto(ctx: Context, modo10x: Boolean): String {
            val p = prefs(ctx)
            val k = clave(modo10x)
            val retiro = if (modo10x) CASHOUT_10X else CASHOUT_2X
            val ganadas = p.getInt("ganadas_$k", 0)
            val perdidas = p.getInt("perdidas_$k", 0)
            val total = ganadas + perdidas
            val pct = if (total > 0) ganadas * 100.0 / total else 0.0
            val sb = StringBuilder()
            sb.append("CONFIGURACIÓN 4x4 - ").append(k).append('\n')
            sb.append("Retiro: ").append(fmt(retiro)).append("x · ").append(ENTRADA_INTENTOS).append(" intentos por entrada\n")
            sb.append("Entrada: última ronda ≥ 2.00x + F1 ≥ 4 + C5 ≥ 4\n\n")
            sb.append("ENTRADAS\n")
            sb.append("Ganadas: ").append(ganadas).append('\n')
            sb.append("Perdidas (3 intentos sin retiro): ").append(perdidas).append('\n')
            sb.append("Efectividad: ").append(String.format(Locale.US, "%.1f", pct)).append("%\n\n")
            sb.append("GANADAS POR INTENTO\n")
            for (i in 1..ENTRADA_INTENTOS) sb.append("Intento ").append(i).append('/').append(ENTRADA_INTENTOS)
                .append(": ").append(p.getInt("winIntento_${k}_$i", 0)).append('\n')
            sb.append("\nRACHAS\n")
            sb.append("Ganadora actual: ").append(p.getInt("rachaG_$k", 0))
                .append(" · máxima: ").append(p.getInt("maxRachaG_$k", 0)).append('\n')
            sb.append("Perdedora actual: ").append(p.getInt("rachaP_$k", 0))
                .append(" · máxima: ").append(p.getInt("maxRachaP_$k", 0))
            return sb.toString()
        }

        fun tablaSenalesTexto(ctx: Context, modo10x: Boolean): String {
            val raw = prefs(ctx).getString("senales_${clave(modo10x)}", "") ?: ""
            val filas = raw.lines().filter { it.isNotBlank() }.map { it.split("|") }.filter { it.size >= 6 }
            val t = StringBuilder()
            t.append("N° Señal | Cuota  | Resultado | Intento | Conex. | Hora\n")
            t.append("---------+--------+-----------+---------+--------+---------\n")
            if (filas.isEmpty()) {
                t.append("Sin señales registradas")
            } else {
                for (f in filas.asReversed().take(100)) {
                    t.append(f[0].padStart(8)).append(" | ").append(f[1].padStart(6)).append(" | ")
                        .append(f[2].padEnd(9)).append(" | ").append(f[3].padStart(7)).append(" | ")
                        .append(f[4].padEnd(6)).append(" | ").append(f[5]).append('\n')
                }
            }
            return t.toString()
        }
    }

    private val appCtx = ctx.applicationContext
    private val p = prefs(appCtx)
    private val k = clave(modo10x)
    private val cashout = if (modo10x) CASHOUT_10X else CASHOUT_2X

    private val historial = ArrayList<Double>()   // índice 0 = ronda más reciente (matriz en memoria)
    private var activa = false
    private var intento = 1                        // intento actual de la entrada activa (1..3)
    private val resultados = ArrayList<Double>()   // resultados de los intentos de la entrada activa
    private var numeroSenalActual = 0
    private var proximoNumeroSenal = 1
    private var ganadas = 0
    private var perdidas = 0
    private val ganadasPorIntento = IntArray(ENTRADA_INTENTOS)
    private var rachaG = 0
    private var maxRachaG = 0
    private var rachaP = 0
    private var maxRachaP = 0
    private var cierre: Cierre? = null

    init {
        historial.addAll(previas.take(MAX_HIST))
        ganadas = p.getInt("ganadas_$k", 0)
        perdidas = p.getInt("perdidas_$k", 0)
        rachaG = p.getInt("rachaG_$k", 0)
        maxRachaG = p.getInt("maxRachaG_$k", 0)
        rachaP = p.getInt("rachaP_$k", 0)
        maxRachaP = p.getInt("maxRachaP_$k", 0)
        proximoNumeroSenal = p.getInt("proximoNumeroSenal_$k", 1).coerceAtLeast(1)
        for (i in 0 until ENTRADA_INTENTOS) ganadasPorIntento[i] = p.getInt("winIntento_${k}_${i + 1}", 0)
    }

    /** Borra la tabla de señales y la matriz en memoria (el historial de rondas lo borra el servicio). */
    fun borrarHistorial() {
        historial.clear()
        activa = false
        resultados.clear()
        numeroSenalActual = 0
        proximoNumeroSenal = 1
        cierre = null
        borrarHistorialPrefs(appCtx)
    }

    /**
     * Datos recibidos al conectar (más reciente primero). Si el websocket entrega 25 o más rondas,
     * la matriz queda completa al instante; si entrega una sola, se usa como ronda de enlace.
     */
    fun sembrar(vals: List<Double>, ahoraMs: Long) {
        if (vals.isEmpty()) return
        if (vals.size >= MATRIX || historial.isEmpty()) {
            if (activa && historial.isNotEmpty() && historial[0] != vals[0]) resolver(vals[0], ahoraMs)
            historial.clear()
            historial.addAll(vals.take(MAX_HIST))
        } else if (historial[0] != vals[0]) {
            // Ronda que cayó mientras no había conexión
            if (activa) nuevaRonda(vals[0], ahoraMs) else agregar(vals[0])
        }
    }

    /** Llega una ronda nueva del websocket. */
    fun nuevaRonda(v: Double, ahoraMs: Long) {
        val resolvio = activa
        if (resolvio) resolver(v, ahoraMs)
        agregar(v)
        // Una ronda que resuelve una entrada nunca genera otra en la misma ronda.
        if (!resolvio && !activa && historial.size >= MATRIX) {
            val (f1, c5) = contar()
            if (v >= TRIGGER && f1 >= MIN_FILA1 && c5 >= MIN_COL5) emitir()
        }
    }

    private fun agregar(v: Double) {
        historial.add(0, v)
        while (historial.size > MAX_HIST) historial.removeAt(historial.size - 1)
    }

    /** Rondas >= 2.00x en F1 y C5 de la matriz 5x5 actual. */
    private fun contar(): Pair<Int, Int> {
        var f = 0
        for (i in 0 until 5) if (historial[i] >= TRIGGER) f++
        var c = 0
        for (r in 0 until 5) if (historial[r * 5 + 4] >= TRIGGER) c++
        return Pair(f, c)
    }

    private fun emitir() {
        activa = true
        intento = 1
        resultados.clear()
        numeroSenalActual = proximoNumeroSenal++
        p.edit().putInt("proximoNumeroSenal_$k", proximoNumeroSenal).apply()
        cierre = null
        cb.alEntrada()
    }

    /** Cada ronda que cae con una entrada activa es un intento. */
    private fun resolver(v: Double, ahoraMs: Long) {
        resultados.add(v)
        val win = v >= cashout
        val usados = resultados.size
        if (!win && usados < ENTRADA_INTENTOS) {
            intento = usados + 1        // sigue la entrada: la próxima ronda es el siguiente intento
            return
        }

        // La entrada termina: ganada en el intento `usados`, o perdida tras 3 intentos
        registrarResultadoSenal(v, win, usados)
        activa = false
        val t = fmt(cashout)
        if (win) {
            ganadas++
            ganadasPorIntento[usados - 1]++
            rachaG++; maxRachaG = maxOf(maxRachaG, rachaG); rachaP = 0
            cierre = Cierre(true, "¡GANAMOS ${t}x!", "Resultado: ${fmt(v)}x - Intento $usados/$ENTRADA_INTENTOS", ahoraMs + Config.CIERRE_MS)
        } else {
            perdidas++
            rachaP++; maxRachaP = maxOf(maxRachaP, rachaP); rachaG = 0
            cierre = Cierre(false, "¡PERDIMOS ${t}x!", "Resultados: " + resultados.joinToString(">") { fmt(it) + "x" }, ahoraMs + Config.CIERRE_MS)
        }
        guardarEstadisticas()
        cb.alFinal(win)
    }

    // ---------------------------------------------------------------- persistencia

    private fun guardarEstadisticas() {
        val e = p.edit()
            .putInt("ganadas_$k", ganadas)
            .putInt("perdidas_$k", perdidas)
            .putInt("rachaG_$k", rachaG)
            .putInt("maxRachaG_$k", maxRachaG)
            .putInt("rachaP_$k", rachaP)
            .putInt("maxRachaP_$k", maxRachaP)
        for (i in 0 until ENTRADA_INTENTOS) e.putInt("winIntento_${k}_${i + 1}", ganadasPorIntento[i])
        e.apply()
    }

    private fun registrarResultadoSenal(cuota: Double, ganada: Boolean, usados: Int) {
        try {
            val n = if (numeroSenalActual > 0) numeroSenalActual else (proximoNumeroSenal - 1).coerceAtLeast(1)
            val resultado = if (ganada) "GANADA" else "PERDIDA"
            val hora = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            val con = "C-" + conexionId().toString().padStart(2, '0')
            val fila = "$n|${fmt(cuota)}x|$resultado|$usados/$ENTRADA_INTENTOS|$con|$hora"
            val clave = "senales_$k"
            val anterior = p.getString(clave, "") ?: ""
            p.edit().putString(clave, if (anterior.isBlank()) fila else anterior + "\n" + fila).apply()
            try {
                val f = File(appCtx.getExternalFilesDir(null), "senales.csv")
                if (!f.exists() || f.length() == 0L) f.writeText(CSV_SENALES)
                f.appendText("$n,${fmt(cuota)}x,$resultado,$usados/$ENTRADA_INTENTOS,$con,$hora\n")
            } catch (_: Exception) { }
        } catch (_: Exception) { }
    }

    // ---------------------------------------------------------------- pantalla

    /** Matriz 5x5: posición 1 = ronda más reciente (arriba a la izquierda). Verde >= 2x, gris < 2x. */
    private fun matriz(): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        val n = historial.size
        for (r in 0 until 5) {
            sb.append("F${r + 1} ")
            for (c in 0 until 5) {
                val idx = r * 5 + c
                val txt: String
                val color: Int
                if (idx < n) {
                    val v = historial[idx]
                    txt = fmt(v).padStart(6)
                    color = if (v >= TRIGGER) Color.rgb(76, 217, 100) else Color.rgb(170, 170, 170)
                } else {
                    txt = "--".padStart(6)
                    color = Color.rgb(90, 90, 90)
                }
                val start = sb.length
                sb.append(txt)
                sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (r == 0 || c == 4) sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            if (r < 4) sb.append('\n')
        }
        return sb
    }

    /** Qué evalúa el modelo para decidir la entrada. */
    private fun evaluacion(): String {
        if (historial.size < MATRIX) return "Evalúa: faltan ${MATRIX - historial.size} rondas"
        val (f1, c5) = contar()
        val ult = if (historial[0] >= TRIGGER) "✓" else "✗"
        return "Evalúa: Últ $ult F1 $f1/$MIN_FILA1 C5 $c5/$MIN_COL5"
    }

    fun vista(ahoraMs: Long): Vista {
        if (activa) {
            val cuerpo = SpannableStringBuilder()
                .append("🏁 RETIRAR EN: ${fmt(cashout)}x\n")
                .append("🔄 INTENTO: $intento/$ENTRADA_INTENTOS\n")
                .append("👉 La siguiente ronda es Intento $intento\n")
                .append(matriz())
            return Vista("✅ ENTRADA CONFIRMADA ✅", cuerpo, Config.VERDE, true)
        }
        val f = cierre
        if (f != null) {
            if (ahoraMs < f.hastaMs) return Vista(f.titulo, f.detalle, if (f.ganada) Config.VERDE else Config.ROJO)
            cierre = null
        }
        val titulo = if (historial.size < MATRIX) "Esperando señal.. (${historial.size}/$MATRIX)" else "Esperando señal.."
        val cuerpo = SpannableStringBuilder().append(evaluacion()).append('\n').append(matriz())
        return Vista(titulo, cuerpo, Config.AMBAR, true)
    }

    fun resumen(): String {
        val sb = StringBuilder()
        sb.append("4x4 · retiro ").append(fmt(cashout)).append("x · ").append(ENTRADA_INTENTOS).append(" intentos por entrada\n")
        sb.append("Entrada activa: ").append(if (activa) "SÍ (intento $intento/$ENTRADA_INTENTOS)" else "no").append('\n')
        sb.append("Matriz: ").append(minOf(historial.size, MATRIX)).append('/').append(MATRIX)
        if (historial.size >= MATRIX) {
            val (f1, c5) = contar()
            sb.append("  ·  F1 ").append(f1).append("/5  ·  C5 ").append(c5).append("/5")
        }
        sb.append("\n\nÚltimas rondas:\n")
        sb.append(if (historial.isEmpty()) "—" else historial.take(12).joinToString("  ") { fmt(it) })
        return sb.toString()
    }
}
