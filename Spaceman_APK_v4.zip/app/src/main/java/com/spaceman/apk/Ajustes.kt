package com.spaceman.apk

import android.content.Context

/** Configuración elegida en la pantalla principal (se aplica al iniciar el bot). */
object Ajustes {
    const val TIEMPO = "tiempo"
    const val CUATRO = "4x4"
    const val AMBAS = "ambas"

    private fun p(ctx: Context) = ctx.getSharedPreferences("spaceman_apk_cfg", Context.MODE_PRIVATE)

    /** Tipo de señales: TIEMPO, CUATRO (4x4) o AMBAS (las dos a la vez). */
    fun estrategia(ctx: Context): String = p(ctx).getString("estrategia", TIEMPO) ?: TIEMPO
    fun setEstrategia(ctx: Context, v: String) { p(ctx).edit().putString("estrategia", v).apply() }

    fun usaTiempo(ctx: Context): Boolean = estrategia(ctx) != CUATRO
    fun usa4x4(ctx: Context): Boolean = estrategia(ctx) != TIEMPO

    /** Solo para 4x4: false = retirar en 2x, true = retirar en 10x (en ambos, 3 intentos por entrada). */
    fun modo10x(ctx: Context): Boolean = p(ctx).getBoolean("modo10x", false)
    fun setModo10x(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("modo10x", v).apply() }
}
