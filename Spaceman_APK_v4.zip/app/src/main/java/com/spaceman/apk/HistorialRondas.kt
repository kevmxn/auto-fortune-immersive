package com.spaceman.apk

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Una ronda guardada. semilla = primer dato al conectar (su hora exacta no se conoce). */
class Ronda(val conexion: Int, val ms: Long, val v: Double, val semilla: Boolean)

/**
 * Historial de rondas guardado en el teléfono, común a las dos estrategias (Tiempo y 4x4).
 * Cada vez que el bot se conecta al websocket se abre una "conexión" (C-01, C-02...) y todas las
 * rondas que llegan se guardan con su conexión y hora. Archivo (se puede copiar desde el teléfono):
 * Android/data/com.spaceman.apk/files/historial_rondas.csv
 */
class HistorialRondas(ctx: Context) {

    companion object {
        const val MAX_RONDAS = 20000
        private const val ENCABEZADO = "conexion,fecha_hora,epoch_ms,multiplicador,tipo\n"

        fun archivo(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "historial_rondas.csv")

        fun leer(ctx: Context): ArrayList<Ronda> {
            val out = ArrayList<Ronda>()
            try {
                val f = archivo(ctx)
                if (!f.exists()) return out
                f.forEachLine { linea ->
                    val c = linea.split(",")
                    if (c.size >= 5) {
                        val con = c[0].toIntOrNull()
                        val ms = c[2].toLongOrNull()
                        val v = c[3].toDoubleOrNull()
                        if (con != null && ms != null && v != null) out.add(Ronda(con, ms, v, c[4].trim() == "semilla"))
                    }
                }
            } catch (_: Exception) { }
            return out
        }

        /** Resumen por conexión (más reciente primero). */
        fun conexionesTexto(ctx: Context): String {
            val rondas = leer(ctx)
            if (rondas.isEmpty()) return "Sin conexiones guardadas"
            val fmtFecha = SimpleDateFormat("dd/MM HH:mm", Locale.US)
            val ids = ArrayList<Int>()
            for (r in rondas) if (ids.isEmpty() || ids[ids.size - 1] != r.conexion) ids.add(r.conexion)
            val sb = StringBuilder()
            sb.append("Conexiones guardadas: ").append(ids.distinct().size).append('\n')
            sb.append("Conex. | Desde        | Hasta        | Rondas\n")
            sb.append("-------+--------------+--------------+-------\n")
            for (id in ids.distinct().asReversed().take(15)) {
                val de = rondas.filter { it.conexion == id }
                sb.append("C-").append(id.toString().padStart(2, '0')).append("   | ")
                    .append(fmtFecha.format(Date(de.first().ms))).append(" | ")
                    .append(fmtFecha.format(Date(de.last().ms))).append(" | ")
                    .append(de.size).append('\n')
            }
            return sb.toString()
        }

        /** Últimas rondas guardadas (más reciente primero). */
        fun rondasTexto(ctx: Context): String {
            val rondas = leer(ctx)
            val sb = StringBuilder()
            sb.append("Total guardado: ").append(rondas.size).append(" rondas (más reciente primero)\n\n")
            rondas.asReversed().take(120).forEachIndexed { i, r ->
                sb.append(i + 1).append(". ").append(fmt(r.v)).append('x')
                if ((i + 1) % 4 == 0) sb.append('\n') else sb.append("   ")
            }
            return sb.toString()
        }
    }

    private val appCtx = ctx.applicationContext
    private val prefs = appCtx.getSharedPreferences("spaceman_apk_hist", Context.MODE_PRIVATE)
    private val fechaFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val rondas: ArrayList<Ronda> = leer(appCtx)

    var conexion = 0
        private set

    init {
        if (rondas.size > MAX_RONDAS) {
            while (rondas.size > MAX_RONDAS) rondas.removeAt(0)
            reescribir()
        }
    }

    /** Se llama cada vez que el websocket se conecta. */
    fun nuevaConexion(): Int {
        val ultima = if (rondas.isEmpty()) 0 else rondas[rondas.size - 1].conexion
        conexion = maxOf(prefs.getInt("conexiones", 0), ultima) + 1
        prefs.edit().putInt("conexiones", conexion).apply()
        return conexion
    }

    fun agregar(v: Double, ms: Long, semilla: Boolean) {
        val r = Ronda(conexion, ms, v, semilla)
        rondas.add(r)
        while (rondas.size > MAX_RONDAS) rondas.removeAt(0)
        try {
            val f = archivo(appCtx)
            if (!f.exists() || f.length() == 0L) f.writeText(ENCABEZADO)
            f.appendText("${r.conexion},${fechaFmt.format(Date(ms))},$ms,${fmt(v)},${if (semilla) "semilla" else "live"}\n")
        } catch (_: Exception) { }
    }

    fun ultima(): Ronda? = if (rondas.isEmpty()) null else rondas[rondas.size - 1]

    /** Rondas "en vivo" desde una hora (más antigua primero): base de la estrategia de Tiempo. */
    fun recientesLive(desdeMs: Long): List<Ronda> = rondas.filter { !it.semilla && it.ms >= desdeMs }

    /**
     * Rondas consecutivas más recientes (más reciente primero), cortando donde haya un hueco
     * mayor a huecoMs (rondas no guardadas): base de la matriz 4x4.
     */
    fun cadenaReciente(ahoraMs: Long, huecoMs: Long, max: Int): List<Double> {
        val out = ArrayList<Double>()
        var ref = ahoraMs
        for (i in rondas.indices.reversed()) {
            val r = rondas[i]
            if (ref - r.ms > huecoMs) break
            out.add(r.v)
            ref = r.ms
            if (out.size >= max) break
        }
        return out
    }

    fun borrar() {
        rondas.clear()
        reescribir()
    }

    private fun reescribir() {
        try {
            val sb = StringBuilder(ENCABEZADO)
            for (r in rondas) {
                sb.append(r.conexion).append(',').append(fechaFmt.format(Date(r.ms))).append(',').append(r.ms)
                    .append(',').append(fmt(r.v)).append(',').append(if (r.semilla) "semilla" else "live").append('\n')
            }
            archivo(appCtx).writeText(sb.toString())
        } catch (_: Exception) { }
    }
}
