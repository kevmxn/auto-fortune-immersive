package com.spaceman.apk

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var estado: TextView
    private lateinit var stats: TextView
    private lateinit var tablaTitulo: TextView
    private lateinit var tabla: TextView
    private lateinit var conexionesTitulo: TextView
    private lateinit var conexiones: TextView
    private lateinit var rondasTitulo: TextView
    private lateinit var rondas: TextView
    private var ultimaLectura = 0L
    private lateinit var modoTitulo: TextView
    private lateinit var modoGroup: RadioGroup

    private val ui = Handler(Looper.getMainLooper())
    private val refresco = object : Runnable {
        override fun run() { pintar(); ui.postDelayed(this, 1000) }
    }

    private fun titulo(txt: String, d: Float) = TextView(this).apply {
        text = txt
        textSize = 17f
        setPadding(0, (12 * d).toInt(), 0, (6 * d).toInt())
    }

    private fun mono(size: Float) = TextView(this).apply {
        textSize = size
        typeface = Typeface.MONOSPACE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad * 2, pad, pad)

        col.addView(TextView(this).apply {
            text = "Spaceman APK\nConfiguración"
            textSize = 22f
            gravity = Gravity.CENTER
        })

        // ---- tipo de señales ----
        col.addView(titulo("TIPO DE SEÑALES", d))
        val rb1 = RadioButton(this).apply {
            text = "1) Tiempo — avisa 60 s antes del pico estimado (categorías 5x a 50x+)"
            textSize = 14f
            id = 3001
        }
        val rb2 = RadioButton(this).apply {
            text = "2) 4x4 — última ronda ≥ 2.00x + F1 ≥ 4 + C5 ≥ 4 (matriz 5x5)"
            textSize = 14f
            id = 3002
        }
        val rb3 = RadioButton(this).apply {
            text = "3) Ambas — Tiempo + 4x4 a la vez (dos alertas flotantes)"
            textSize = 14f
            id = 3003
        }
        val tipoGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            addView(rb1)
            addView(rb2)
            addView(rb3)
        }
        tipoGroup.check(
            when (Ajustes.estrategia(this)) {
                Ajustes.CUATRO -> rb2.id
                Ajustes.AMBAS -> rb3.id
                else -> rb1.id
            }
        )
        col.addView(tipoGroup)

        // ---- configuración 4x4 ----
        modoTitulo = titulo("CONFIGURACIÓN 4x4", d)
        col.addView(modoTitulo)
        val rbA = RadioButton(this).apply {
            text = "Retirar en 2.00x — 3 intentos por entrada"
            textSize = 14f
            id = 3011
        }
        val rbB = RadioButton(this).apply {
            text = "Retirar en 10.00x — 3 intentos por entrada"
            textSize = 14f
            id = 3012
        }
        modoGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            addView(rbA)
            addView(rbB)
        }
        modoGroup.check(if (Ajustes.modo10x(this)) rbB.id else rbA.id)
        col.addView(modoGroup)

        tipoGroup.setOnCheckedChangeListener { _, id ->
            Ajustes.setEstrategia(this, when (id) {
                rb2.id -> Ajustes.CUATRO
                rb3.id -> Ajustes.AMBAS
                else -> Ajustes.TIEMPO
            })
            avisoReinicio()
            pintar()
        }
        modoGroup.setOnCheckedChangeListener { _, id ->
            Ajustes.setModo10x(this, id == rbB.id)
            avisoReinicio()
            pintar()
        }

        // ---- botones ----
        col.addView(Button(this).apply {
            text = "1) Permiso de alerta flotante"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        col.addView(Button(this).apply {
            text = "2) INICIAR"
            setOnClickListener { iniciar() }
        })
        col.addView(Button(this).apply {
            text = "DETENER"
            setOnClickListener {
                stopService(Intent(this@MainActivity, BotService::class.java))
                Toast.makeText(this@MainActivity, "Detenido", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(Button(this).apply {
            text = "BORRAR HISTORIAL"
            setOnClickListener {
                if (BotService.running) {
                    startService(Intent(this@MainActivity, BotService::class.java).setAction(BotService.ACTION_RESET))
                } else {
                    HistorialRondas(this@MainActivity).borrar()
                    Estrategia4x4.borrarHistorialPrefs(this@MainActivity)
                }
                Toast.makeText(this@MainActivity, "Historial borrado", Toast.LENGTH_SHORT).show()
                ultimaLectura = 0L
                pintar()
            }
        })

        // ---- estado en vivo + estadísticas ----
        estado = mono(13f).apply { setPadding(0, (12 * d).toInt(), 0, 0) }
        col.addView(estado)

        stats = TextView(this).apply {
            textSize = 14f
            setPadding(0, (12 * d).toInt(), 0, 0)
        }
        col.addView(stats)

        tablaTitulo = titulo("HISTORIAL DE SEÑALES", d)
        col.addView(tablaTitulo)
        tabla = mono(12f)
        val hs = HorizontalScrollView(this)
        hs.addView(tabla)
        col.addView(hs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        conexionesTitulo = titulo("HISTORIAL POR CONEXIÓN", d)
        col.addView(conexionesTitulo)
        conexiones = mono(12f)
        val hs2 = HorizontalScrollView(this)
        hs2.addView(conexiones)
        col.addView(hs2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        rondasTitulo = titulo("HISTORIAL DE RONDAS", d)
        col.addView(rondasTitulo)
        rondas = mono(13f)
        col.addView(rondas)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        pintar()
    }

    private fun avisoReinicio() {
        if (BotService.running) {
            Toast.makeText(this, "Configuración guardada. Detén e inicia para aplicarla.", Toast.LENGTH_LONG).show()
        }
    }

    private fun iniciar() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primero concede el permiso de superposición", Toast.LENGTH_LONG).show()
            return
        }
        if (BotService.running) {
            Toast.makeText(this, "Ya está en marcha", Toast.LENGTH_SHORT).show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, BotService::class.java))
        moveTaskToBack(true)
    }

    private fun poner(t: TextView, nuevo: String) {
        if (t.text.toString() != nuevo) t.text = nuevo
    }

    private fun pintar() {
        val es4x4 = Ajustes.usa4x4(this)
        val m10 = Ajustes.modo10x(this)
        val vis = if (es4x4) View.VISIBLE else View.GONE
        modoTitulo.visibility = vis
        modoGroup.visibility = vis
        stats.visibility = vis
        tablaTitulo.visibility = vis
        tabla.visibility = vis

        poner(estado, if (BotService.running) "● EN MARCHA - ${BotState.conexion}\n\n${BotState.resumen}" else "○ Detenido")
        if (es4x4) {
            poner(stats, Estrategia4x4.estadisticasTexto(this, m10))
            poner(tabla, Estrategia4x4.tablaSenalesTexto(this, m10))
        }
        // El historial guardado es común a las dos estrategias; se relee cada 5 s
        val ahora = System.currentTimeMillis()
        if (ahora - ultimaLectura > 5000) {
            ultimaLectura = ahora
            poner(conexiones, HistorialRondas.conexionesTexto(this))
            poner(rondas, HistorialRondas.rondasTexto(this))
        }
    }

    override fun onResume() { super.onResume(); ui.post(refresco) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(refresco) }
}
