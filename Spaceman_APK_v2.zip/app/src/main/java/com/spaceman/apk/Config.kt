package com.spaceman.apk

import java.util.Locale

/** Categoría de pico: rango [min, max) del multiplicador. */
data class Categoria(
    val id: String,
    val rango: String,
    val min: Double,
    val max: Double,
    val color: Int,
    val intentos: Int      // rondas disponibles para conseguir el 2x
)

object Config {
    // ===== WebSocket de Spaceman (mismos datos que websocket_spaceman.py) =====
    const val WS_URL = "wss://dga.pragmaticplaylive.net/ws"
    const val CASINO_ID = "ppcdk00000005349"
    const val CURRENCY = "BRL"
    const val GAME_ID = 1301

    // ===== Estrategia de tiempo (del HTML) =====
    const val MIN_REGISTROS = 4        // registros por categoría para activar la señal
    const val AVISO_ANTES = 60         // segundos antes del pico estimado (antes 40)

    // ===== Rondas para conseguir el 2x =====
    const val TARGET = 2.00            // retirar en 2.00x
    const val RONDAS_ENTRADA = 1       // rondas que caen tras el aviso antes de contar el Intento 1
    const val AVISO_MAX_SEG = 600      // si no llegan rondas en 10 min, se descarta la señal

    // ===== Varios =====
    const val MAX_REGISTROS_CAT = 50
    const val MAX_EDAD_SEG = 3 * 3600L // al reabrir, se olvidan registros de más de 3 h
    const val CIERRE_MS = 15_000L      // tiempo que se muestra GANAMOS / PERDIMOS

    const val VERDE = 0xFF00E676.toInt()
    const val ROJO = 0xFFFF5252.toInt()
    const val AMBAR = 0xFFFFB300.toInt()

    // Las rondas de 50x o más entran todas en la última categoría (aunque el rango sea 50-100x).
    val CATEGORIAS = listOf(
        Categoria("c5a", "5.00-6.99x", 5.0, 7.0, 0xFFFFCC00.toInt(), 4),
        Categoria("c5b", "7.00-8.99x", 7.0, 9.0, 0xFFFF7A5C.toInt(), 4),
        Categoria("c5c", "9.00-9.99x", 9.0, 10.0, 0xFFF5C542.toInt(), 4),
        Categoria("c10a", "10.00-29.99x", 10.0, 30.0, 0xFFB0B6C0.toInt(), 4),
        Categoria("c10b", "30.00-49.99x", 30.0, 50.0, 0xFF4ADE80.toInt(), 4),
        Categoria("c10c", "50.00x+", 50.0, Double.MAX_VALUE, 0xFFFF7EB6.toInt(), 4)
    )
}

object BotState {
    @Volatile var conexion = "Detenido"
    @Volatile var resumen = ""
}

fun mmss(seg: Double): String {
    val s = Math.max(0L, Math.round(seg))
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)
