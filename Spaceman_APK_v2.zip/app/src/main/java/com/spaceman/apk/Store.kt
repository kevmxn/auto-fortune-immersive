package com.spaceman.apk

import android.content.Context

/** Guarda los registros de cada categoría (segundos epoch) para no perder el calentamiento al reabrir. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("spaceman_apk_tiempo", Context.MODE_PRIVATE)

    fun cargar(id: String, ahoraS: Long): ArrayList<Long> {
        val out = ArrayList<Long>()
        val txt = sp.getString("r_$id", "") ?: ""
        for (p in txt.split(",")) {
            val v = p.toLongOrNull() ?: continue
            if (ahoraS - v <= Config.MAX_EDAD_SEG) out.add(v)
        }
        return out
    }

    fun guardar(id: String, lista: List<Long>) {
        sp.edit().putString("r_$id", lista.joinToString(",")).apply()
    }

    fun borrarTodo() {
        sp.edit().clear().apply()
    }
}
