package com.spaceman.apk

import android.content.Context

/** Configuración elegida en la pantalla principal (se aplica al iniciar el bot). */
object Ajustes {
    private fun p(ctx: Context) = ctx.getSharedPreferences("spaceman_apk_cfg", Context.MODE_PRIVATE)

    /** true = señales 4x4, false = señales de Tiempo. */
    fun es4x4(ctx: Context): Boolean = p(ctx).getString("estrategia", "tiempo") == "4x4"
    fun set4x4(ctx: Context, v: Boolean) { p(ctx).edit().putString("estrategia", if (v) "4x4" else "tiempo").apply() }

    /** Solo para 4x4: false = retirar en 2x (6 intentos), true = retirar en 10x (28 intentos). */
    fun modo10x(ctx: Context): Boolean = p(ctx).getBoolean("modo10x", false)
    fun setModo10x(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("modo10x", v).apply() }
}
