package com.spaceman.apk

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Cliente del WebSocket de Spaceman (Pragmatic Play). Reconecta solo cada 5 s si se cae. */
class SpacemanSocket(
    private val onSeed: (List<Double>) -> Unit,     // primer mensaje tras conectar (más reciente primero)
    private val onRound: (Double, Long) -> Unit,    // ronda nueva en vivo
    private val onState: (String) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private val handler = Handler(Looper.getMainLooper())
    private var ws: WebSocket? = null
    private var gen = 0
    @Volatile private var stopped = true
    private var lastKey: String? = null
    private var primed = false

    fun start() {
        stopped = false
        connect()
    }

    fun stop() {
        stopped = true
        gen++
        handler.removeCallbacksAndMessages(null)
        ws?.cancel()
        ws = null
    }

    private fun connect() {
        if (stopped) return
        val mine = ++gen
        primed = false
        onState("Conectando...")
        val req = Request.Builder().url(Config.WS_URL).build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (mine != gen) return
                val sub = JSONObject()
                    .put("type", "subscribe")
                    .put("casinoId", Config.CASINO_ID)
                    .put("currency", Config.CURRENCY)
                    .put("key", JSONArray().put(Config.GAME_ID))
                webSocket.send(sub.toString())
                onState("Conectado (juego ${Config.GAME_ID})")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (mine == gen) handle(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (mine == gen) handle(bytes.utf8())
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (mine == gen) retry("Desconectado")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (mine == gen) retry("Error: ${t.message ?: "conexión"}")
            }
        })
    }

    private fun retry(msg: String) {
        if (stopped) return
        gen++   // invalida callbacks de la conexión caída
        onState("$msg - reconectando en 5 s")
        handler.postDelayed({ connect() }, 5000)
    }

    private fun pick(o: JSONObject, k: String): String? =
        if (o.has(k) && !o.isNull(k)) o.get(k).toString() else null

    private fun valorDe(item: JSONObject): Double? {
        val raw = pick(item, "result") ?: pick(item, "multiplier") ?: pick(item, "crashPoint") ?: return null
        return raw.replace("x", "", ignoreCase = true).trim().toDoubleOrNull()
    }

    private fun handle(text: String) {
        val data = try { JSONObject(text) } catch (e: Exception) { return }
        val arr = data.optJSONArray("gameResult") ?: return
        if (arr.length() == 0) return
        val item = arr.optJSONObject(0) ?: return
        val v = valorDe(item) ?: return
        val id = pick(item, "gameId") ?: pick(item, "id") ?: ""
        val key = "$id|$v"
        if (key == lastKey) return
        lastKey = key
        if (!primed) {
            // Primer dato tras conectar: suele ser la última ronda ya jugada (a veces con historial).
            // No cuenta como ronda nueva; se entrega como "semilla".
            primed = true
            val vals = ArrayList<Double>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                valorDe(o)?.let { vals.add(it) }
            }
            onState("Conectado - esperando próxima ronda")
            onSeed(vals)
            return
        }
        onRound(v, System.currentTimeMillis())
    }
}
