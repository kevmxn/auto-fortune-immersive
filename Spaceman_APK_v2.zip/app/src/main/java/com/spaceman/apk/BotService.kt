package com.spaceman.apk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

class BotService : Service(), Engine.Callbacks, Estrategia4x4.Callbacks {

    companion object {
        @Volatile var running = false
        const val ACTION_RESET = "com.spaceman.apk.RESET"
        private const val CH = "spaceman_apk"
    }

    private val ui = Handler(Looper.getMainLooper())
    private var overlay: FloatingAlert? = null
    private var tiempo: Engine? = null          // señales de Tiempo
    private var cuatro: Estrategia4x4? = null   // señales 4x4
    private var socket: SpacemanSocket? = null
    private var wake: PowerManager.WakeLock? = null

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            tiempo?.tick(now)
            refrescar(now)
            ui.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_RESET) {
            if (tiempo == null && cuatro == null) { stopSelf(); return START_NOT_STICKY }
            tiempo?.reset()
            cuatro?.borrarHistorial()
            refrescar(System.currentTimeMillis())
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        running = true

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "spacemanapk:ws")
            wake?.acquire(12 * 60 * 60 * 1000L)
        } catch (_: Exception) { }

        // Estrategia elegida en la configuración
        if (Ajustes.es4x4(this)) {
            cuatro = Estrategia4x4(this, Ajustes.modo10x(this), this)
        } else {
            tiempo = Engine(Store(this), this)
        }

        overlay = FloatingAlert(this) { stopSelf() }
        try { overlay?.show() } catch (_: Exception) { BotState.conexion = "Falta permiso de superposición" }

        socket = SpacemanSocket(
            onSeed = { vals -> ui.post { cuatro?.sembrar(vals, System.currentTimeMillis()); refrescar(System.currentTimeMillis()) } },
            onRound = { v, ms ->
                ui.post {
                    tiempo?.onRound(v, ms)
                    cuatro?.nuevaRonda(v, ms)
                    refrescar(System.currentTimeMillis())
                }
            },
            onState = { s -> BotState.conexion = s }
        )
        socket?.start()

        ui.post(tick)
        return START_NOT_STICKY
    }

    private fun refrescar(ahoraMs: Long) {
        val t = tiempo
        val c = cuatro
        if (c != null) {
            val v = c.vista(ahoraMs)
            overlay?.update(v.titulo, v.detalle, v.color, v.mono)
            BotState.resumen = c.resumen()
        } else if (t != null) {
            val v = t.vista(ahoraMs)
            overlay?.update(v.titulo, v.detalle, v.color, v.mono)
            BotState.resumen = t.resumen(ahoraMs)
        }
    }

    // ---- avisos ----
    override fun alSenal(cat: Categoria) {
        pitidos(3)
        vibrar(longArrayOf(0, 200, 100, 200))
    }

    override fun alEntrada() {
        pitidos(3)
        vibrar(longArrayOf(0, 300, 120, 300))
    }

    override fun alFinal(ganada: Boolean) {
        if (ganada) { pitidos(1); vibrar(longArrayOf(0, 300)) }
        else { pitidos(2); vibrar(longArrayOf(0, 120, 80, 120, 80, 120)) }
    }

    private fun pitidos(n: Int) {
        Thread {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
                repeat(n) { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150); Thread.sleep(230) }
                Thread.sleep(150)
                tg.release()
            } catch (_: Exception) { }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun vibrar(patron: LongArray) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(patron, -1))
        } catch (_: Exception) { }
    }

    // ---- notificación ----
    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Spaceman APK", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("Spaceman APK")
            .setContentText("Escuchando rondas de Spaceman")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        running = false
        ui.removeCallbacks(tick)
        socket?.stop()
        overlay?.hide()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) { }
        BotState.conexion = "Detenido"
        BotState.resumen = ""
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
