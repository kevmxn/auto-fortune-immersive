# Spaceman APK
App Android (nueva, id `com.spaceman.apk`) que se conecta al websocket de Spaceman y emite señales
en una alerta flotante. En la pantalla de Configuración se elige el tipo de señales:

1) **Tiempo** – registra sola cada ronda por categoría (5-6.99x, 7-8.99x, 9-9.99x, 10-29.99x, 30-49.99x, 50x+),
   estima el próximo pico (promedio de intervalos, mínimo 4 registros) y avisa 60 s antes.
   Después da hasta 4 rondas para conseguir 2.00x.
2) **4x4** – matriz 5x5 (últimas 25 rondas). Señal cuando la última ronda es >= 2.00x, F1 tiene 4-5 rondas >= 2.00x
   y C5 tiene 4-5 rondas >= 2.00x. Retiro 2x (6 intentos por sesión) o 10x (28 intentos por sesión).
   Estadísticas, historial de señales (tabla) y rondas en la pantalla de Configuración.
   También se guardan rondas.csv y senales.csv en Android/data/com.spaceman.apk/files.

Para cambiar de tipo de señales: detener e iniciar de nuevo.
Compilar: subir Spaceman_APK.zip al repositorio y ejecutar el workflow "Build Spaceman APK".
Ajustes de Tiempo (aviso, rondas, categorías): app/src/main/java/com/spaceman/apk/Config.kt
